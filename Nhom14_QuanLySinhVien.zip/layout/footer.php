<footer class="text-center py-2 bg-blue-900 text-white">
        <p>Thiết kế 2016-2024 bởi CUSC</p>
    </footer>
</html>